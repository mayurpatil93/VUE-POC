<template>
   <base-card>
   <p class="logoheader"><img alt="Vue logo"  src="@/assets/logo.svg" width="75" height="75" /></p>
   <p class="logoheader">Welcome </p>
   <form @submit.prevent="onSubmit(email, password)">
        
        <div class="form-control">
            <label for="email">E-Mail</label>
            <input type="email" id="email"  v-model="email"/>
        </div>
        <div class="form-control">
            <label for="password">Password</label>
            <input type="password" id="password"  v-model="password"/>
        </div>
        <base-button>Login</base-button>
        <P v-if="!isValid" class="errors" > Please Check Mail/User Id </P>
      
    </form>
</base-card>
</template>

<script>
export default{
    data() {
    return {
      email: null,
      password: null,
      isValid:true
    };
  },
  methods: {
    onSubmit(email, password) {
        debugger 
        this.isValid = true;
        if(this.email != null && this.email.length > 6){
            this.$router.replace('/template')
        }
        else{
        this.isValid = false;
        }
      
     
    }
  },
}
</script>

<style scoped>
form {
  margin: 1rem;
  padding: 1rem;
}

.form-control {
  margin: 0.5rem 0;
}

label {
  font-weight: bold;
  margin-bottom: 0.5rem;
  display: block;
}

input,
textarea {
  display: block;
  width: 60%;
  height: 40px;
  font: inherit;
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 0.15rem;
}

input:focus,
textarea:focus {
  border-color: #3d008d;
  background-color: #faf6ff;
  outline: none;
}

.errors {
  font-weight: bold;
  color: red;
}

.actions {
  text-align: center;
}

.logoheader{
    max-width: fit-content;
    margin: auto;
    font-weight: bold;
    color: rgb(214, 104, 2);
    font-size: xx-large;
}

.card {
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  padding: 1rem;
  margin: 2rem auto;
  max-width: 40rem;
}
</style>