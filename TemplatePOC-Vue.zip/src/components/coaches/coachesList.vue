<template>
    <theHeader></theHeader>
    <section>
    <filter-item @change-filter="setFilters"></filter-item>
    </section>
    <section>
        <base-card>
        <div class="controls">
            <!-- <base-button mode="outline">Refresh</base-button> -->
          

        </div>
        <ul v-if="hasCoaches">
           <coach-item v-for="coach in filteredCoaches" 
           :key="coach.id"
           :id="coach.id"
           :first-name ="coach.firstName"
           :last-name ="coach.lastName"
           :areas="coach.areas"
           :rate="coach.hourlyRate"
           :details="coach.details"
           :title="coach.title"
           ></coach-item>
        </ul>
        <h3 v-else>No Resource Found.</h3>
        </base-card>
    </section>
</template>

<script>
import coachItem from "../../commonPages/coaches/coachItem.vue"
import filterItem from "../../commonPages/coaches/filterItem.vue"
import theHeader from "../layout/theHeader.vue"

export default {
    components:{
     coachItem,
     filterItem,
     theHeader
    },

    data(){
       return{
         activefilters:{
            frontend:true,
            backend:true,
            career:true,
            discussion:true,
            active:true,
            engage:true
        }
    }

    },
    computed:{
        filteredCoaches(){
            const coaches = this.$store.getters['coaches/coaches'];
            return coaches.filter(coach=>{
                if(this.activefilters.frontend && coach.areas.includes('frontend')){
                    return true;
                }
                if(this.activefilters.backend && coach.areas.includes('backend')){
                    return true;
                }
                if(this.activefilters.engage && coach.areas.includes('engage')){
                    return true;
                }
                if(this.activefilters.discussion && coach.areas.includes('discussion')){
                    return true;
                }
                if(this.activefilters.active && coach.areas.includes('active')){
                    return true;
                }

                return false;

            });
        },

        hasCoaches(){
            return this.$store.getters['coaches/hasCoaches']
        },
        isCoach(){
            return this.$store.getters['coaches/isCoach'];
        }

    },
    methods:{
        setFilters(updatefilters){
            this.activefilters=updatefilters;

        }
    }
}
</script>

<style scoped>
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}

.controls {
  display: flex;
  justify-content: space-between;
}
</style>