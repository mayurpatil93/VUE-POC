<template>
     <theHeader></theHeader>
    <section>
        <div class="card">
        <base-card>
        <h2>Publish Template !</h2>
        <add-form @save-data="saveData"></add-form>
        </base-card>
        </div>
    </section>
</template>

<script>
import addForm from '../../commonPages/coaches/addForm.vue'
import theHeader from '../layout/theHeader.vue'
export default
{
    components:{
        addForm,
        theHeader
    },
    
    methods:{
        saveData(data){
            this.$store.dispatch('coaches/addCoach',data);
            this.$router.replace('/template')
        }
    }
    
}
</script>
<style scoped>

.card {
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  padding: 1rem;
  margin: 2rem auto;
  max-width: 40rem;
}

</style>