<template>
    <theHeader></theHeader>
    <section>
        <base-card>
        <h2>{{ fullName }}</h2>
        </base-card>
    </section>
    <section>
        <base-card>
        <header>
            <h2>{{title}}</h2>
        </header>
        <RouterView></RouterView>
        </base-card>
    </section>
    <section>
        <base-card>
        <base-badge v-for="area in areas" :key="area" :title="area" :type="area"></base-badge>
        <p>{{ description }}</p>
        <p> <b>Overview: </b>{{ details }}</p>
        </base-card>
    </section>
</template>

<script>
import theHeader from '../layout/theHeader.vue'
export default{
    components:{
        theHeader
    },
    props:['id'],
    computed:{

        fullName(){
            return this.selectedCoach.firstName + ' ' + this.selectedCoach.lastName;
        },
        areas(){
            return this.selectedCoach.areas;
        },
        rate(){
            return this.selectedCoach.hourlyRate;
        },
        description(){
            return this.selectedCoach.description;
        },
        title(){
            return this.selectedCoach.title;
        },
        details(){
            return this.selectedCoach.details;
        }

    },
    data(){
        return{
            selectedCoach : null,
        };
    },
    created(){
        this.selectedCoach = this.$store.getters['coaches/coaches'].find(
        (coach)=> coach.id ===this.id)
    }
}
</script>

<style scoped>
.card {
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  padding: 1rem;
  margin: 2rem auto;
  max-width: 40rem;
}
</style>