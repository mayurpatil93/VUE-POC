<template>
    <theHeader></theHeader>
    <section>
        <base-card>
        <h2>{{ fullName }}</h2>
        </base-card>
    </section>
    <section>
        <base-card>
        <header>
            <h2>Interested ? Reach Out Now</h2>
        </header>
        <RouterView></RouterView>
        </base-card>
    </section>
</template>

<script>
import theHeader from '../layout/theHeader.vue'
export default{
    components:{
        theHeader
    },
    props:['id'],
    computed:{

        fullName(){
            return this.selectedCoach.firstName + '' + this.selectedCoach.lastName;
        },
        areas(){
            return this.selectedCoach.areas;
        },
        rate(){
            return this.selectedCoach.hourlyRate;
        },
        description(){
            return this.selectedCoach.description;
        }

    },
    data(){
        return{
            selectedCoach : null,
        };
    },
    created(){
        this.selectedCoach = this.$store.getters['coaches/coaches'].find(
        (coach)=> coach.id ===this.id)
    }
}
</script>