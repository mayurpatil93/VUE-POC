<template>
    <theHeader></theHeader>
   <section >
    <base-card>
    <header>
        <h2>
            Request Received 
        </h2>
    </header>
    <ul v-if="hasRequests">
        <request-item v-for="req in receivedRequest" :key="req.id" 
        :email="req.userEmail" :message="req.message"
        ></request-item>
    </ul>
    <h3 v-else>
        You Have Not Received any Request!
    </h3>
    </base-card>
   </section>
</template>

<script>
import requestItem from '../../commonPages/requests/requestItems.vue'
import theHeader from '../layout/theHeader.vue'
export default{
    components:{requestItem,theHeader},
    computed:{
        receivedRequest(){
            return this.$store.getters['requests/requests'];
        },
        hasRequests(){
            return this.$store.getters['requests/hasRequests']
        }
    }

}
</script>

<style scoped>
header {
  text-align: center;
}

ul {
  list-style: none;
  margin: 2rem auto;
  padding: 0;
  max-width: 30rem;
}

h3 {
  text-align: center;
}

.card {
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  padding: 1rem;
  margin: 2rem auto;
  max-width: 40rem;
}
</style>