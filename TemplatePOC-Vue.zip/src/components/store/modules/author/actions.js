export default{
    addCoach(context,data){

        const coachData ={
            id:context.rootGetters.userId,
            firstName:data.first,
            lastName:data.last,
            description:data.desc,
            hourlyRate:data.rate,
            areas:data.areas,
            details:data.details,
            title:data.title
        }

        context.commit('addCoach',coachData);

    }
}