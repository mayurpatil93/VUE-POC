export default{
    addCoach(state,payload){
        state.coaches.push(payload);
    }
}