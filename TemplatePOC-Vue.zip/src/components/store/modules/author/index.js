import mutations from './mutations.js'
import getters from './getters.js'
import actions from './actions.js'

export default{
    namespaced: true,
    state() {
         
        return {
            coaches:[
                {
                  id: 'c1',
                  title:'Grading Rubric',
                  firstName: 'Maximilian',
                  lastName: 'Schwarzmüller',
                  areas: ['discussion','active'],
                  description:
                    "I'm Maximilian and I've worked as a freelance web developer for years. Let me help you become a developer as well!",
                  hourlyRate: 30,
                  details:"Creating a grading rubric enables you to set clear expectations for students while making grading easier for you. Start by choosing an assignment in your course. Then, follow the prompts below to create a grading rubric for that assignment."
                },
                {
                  id: 'c2',
                  title:'Discussion Board - Real World Applicatios',
                  firstName: 'Julie',
                  lastName: 'Jones',
                  areas: ['active'],
                  description:
                    'I am Julie and as a senior developer in a big tech company, I can help you get your first job or progress in your current role.',
                  hourlyRate: 30,
                  details:" There are a number of ways to enliven discussions and engage students while promoting deeper learning and creating community in the classroom. When students draw connections between the real world and the concepts they are studying, they learn more – and enjoy doing it! Respond to the following prompts to create a real-world application discussion board activity tailored for your course and students."
                }
              ]
        }
    },
    mutations,
    getters,
    actions

}