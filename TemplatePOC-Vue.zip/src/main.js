import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

import store from './components/store/index.js'

import baseCard from './commonPages/UI/baseCard.vue'
import baseButton from './commonPages/UI/baseButton.vue'
import baseBadge from './commonPages/UI/baseBadge.vue'

import './assets/main.css'

const app = createApp(App)

app.use(router)
app.use(store)

app.component('base-card',baseCard)
app.component('base-button',baseButton)
app.component('base-badge',baseBadge)
app.mount('#app')
