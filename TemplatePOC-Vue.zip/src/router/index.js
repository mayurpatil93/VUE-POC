import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import coachDetails from '../components/coaches/coachDetails.vue'
import coachesList from '../components/coaches/coachesList.vue'
import coachRegisteration from '../components/coaches/coachRegisteration.vue'
import contactCoach from '../components/requests/contactCoach.vue'
import requestReceive from '../components/requests/requestReceive.vue'
import signin from '../components/login/signin.vue'
import templateDetails from '../components/coaches/templateDetails.vue'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: signin
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import('../views/AboutView.vue')
    },
    {path:'/template',component:coachesList},
    {path:'/template/:id',component:templateDetails,
    props:true, 
    children:[
      {path:'contact',component:contactCoach},
    ]},
    {path:'/register',component:coachRegisteration},
    {path:'/requests',component:requestReceive},
    {path:'/login',component:signin},
    {path:'/:notfound(.*)',component:null},
    
  ]
})

export default router
