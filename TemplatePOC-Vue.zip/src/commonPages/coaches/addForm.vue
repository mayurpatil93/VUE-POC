<template>
    <form @submit.prevent="submitForm">
        <div class="form-control" :class="{invalid:!firstName.isValid}">
            <label for="firstname">First Name</label>
            <input type="text"  id="firstname" v-model.trim="firstName.val" @blur="updateValidity('firstName')"/>
            <p v-if="!firstName.isValid"> Cannot Be Empty</p>
        </div>
        <div class="form-control" :class="{invalid:!lastName.isValid}">
            <label for="lastname">Last Name</label>
            <input type="text"  id="lastname" v-model.trim="lastName.val" @blur="updateValidity('lastName')"/>
            <p v-if="!lastName.isValid"> Cannot Be Empty</p>
        </div>
        <div class="form-control" :class="{invalid:!title.isValid}">
            <label for="title">Title</label>
            <input type="text"  id="title" v-model.trim="title.val" @blur="updateValidity('title')"/>
            <p v-if="!title.isValid"> Cannot Be Empty</p>
        </div>
        <div class="form-control" :class="{invalid:!description.isValid}">
            <label for="description">Description</label>
            <textarea id="description" rows="5" v-model.trim="description.val" @blur="updateValidity('description')"></textarea>
            <p v-if="!description.isValid"> Cannot Be Empty</p>
        </div>
        <div class="form-control" :class="{invalid:!details.isValid}">
            <label for="details">Details</label>
            <textarea id="details" rows="5" v-model.trim="details.val" @blur="updateValidity('details')"></textarea>
            <p v-if="!details.isValid"> Cannot Be Empty</p>
        </div>
        <div class="form-control" :class="{invalid:!rate.isValid}">
            <label for="rate">Price</label>
            <input type="number"  id="rate" v-model.number="rate.val" @blur="updateValidity('rate')"/>
            <p v-if="!rate.isValid"> Cannot Be Empty</p>
        </div>
        <div class="form-control" :class="{invalid:!areas.isValid}">
            <h3>Tags to be Linked</h3>
            <div>
                <input  type="checkbox" id="active" value="active" v-model="areas.val" @blur="updateValidity('areas')">
                <label for="active">Active</label>
            </div>
            <div>
                <input  type="checkbox" id="discussion" value="discussion" v-model="areas.val"  @blur="updateValidity('areas')">
                <label for="discussion">Discussion</label>
            </div>
            <div>
                <input  type="checkbox" id="engage" value="engage" v-model="areas.val"  @blur="updateValidity('areas')">
                <label for="engage">Enagage</label>
            </div>
            <p v-if="!areas.isValid"> Cannot Be Empty</p>
        </div>
        <p v-if="!isFormValid"> Please Check the fields and Submit Again</p>
        <base-button>Register</base-button>

    </form>
</template>

<script>
export default{
    emits:['save-data'],
    data(){
        return{
            firstName:{
                val:'',
                isValid:true
            },
            lastName:{
                val:'',
                isValid:true
            },
            description:{
                val:'',
                isValid:true
            },
            rate:{
                val:null,
                isValid:true
            },
            areas:{
                val:[],
                isValid:true
            },
            title:{
                val:'',
                isValid:true
            },
            details:{
                val:'',
                isValid:true
            },
            isFormValid:true
        }      
    },
    methods:{
        updateValidity(input){
            this[input].isValid =true;

        },
        validateForm(){
            this.isFormValid = true
            if(this.firstName.val === ''){
                this.firstName.isValid = false;
                this.isFormValid = false;
            }
            if(this.lastName.val === ''){
                this.lastName.isValid = false;
                this.isFormValid = false;
            }
            if(this.description.val === ''){
                this.description.isValid = false;
                this.isFormValid = false;
            }
            if(this.title.val === ''){
                this.title.isValid = false;
                this.isFormValid = false;
            }
            if(this.details.val === ''){
                this.title.isValid = false;
                this.isFormValid = false;
            }
            if(!this.rate.val || this.rate.val < 0){
                this.rate.isValid = false;
                this.isFormValid = false;
            }
            if(this.areas.val.length === 0){
                this.areas.isValid = false;
                this.isFormValid = false;
            }

        },
        submitForm(){



            this.validateForm();

            if(!this.isFormValid){
                return;
            }

            const formData={
                first:this.firstName.val,
                last:this.lastName.val,
                rate:this.rate.val,
                desc:this.description.val,
                areas:this.areas.val,
                title:this.title.val,
                details:this.details.val
            };

           this.$emit('save-data',formData)
        }
            
        }

}
</script>

<style scoped>
.form-control {
  margin: 0.5rem 0;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 0.5rem;
}

input[type='checkbox'] + label {
  font-weight: normal;
  display: inline;
  margin: 0 0 0 0.5rem;
}

input,
textarea {
  display: block;
  width: 100%;
  border: 1px solid #ccc;
  font: inherit;
}

input:focus,
textarea:focus {
  background-color: #f0e6fd;
  outline: none;
  border-color: #3d008d;
}

input[type='checkbox'] {
  display: inline;
  width: auto;
  border: none;
}

input[type='checkbox']:focus {
  outline: #3d008d solid 1px;
}

h3 {
  margin: 0.5rem 0;
  font-size: 1rem;
}

.invalid label {
  color: red;
}

.invalid input,
.invalid textarea {
  border: 1px solid red;
}
</style>