<template>
    <span class="badge" :class="type">
        {{ text }}
    </span>
</template>

<script>
export default{
    props:['title','type'],
    computed:{
        text(){
            return this.title.toUpperCase();
        }
    }
}
</script>

<style scoped>

.badge {
  background-color: #ccc;
  color: #252525;
  border-radius: 30px;
  padding: 0.5rem 1.5rem;
  display: inline-block;
  margin-right: 0.5rem;
  font-size: 10px;
}

.discussion{
  background-color: #cf7105;
  color: white;
}
.active{
  background-color: #cf7105;
  color: white;
}

.engage{
  background-color: #cf7105;
  color: white;
}
</style>