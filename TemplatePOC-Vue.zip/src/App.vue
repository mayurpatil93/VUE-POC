<script >
import { RouterLink, RouterView } from 'vue-router'
import theHeader from './components/layout/theHeader.vue';

export default {
  components:{
    theHeader
  }
}
</script>

<template>
  <!-- <header>
     <img alt="Vue logo" class="logo" src="@/assets/logo.svg" width="125" height="125" />

    <div class="wrapper">
      <HelloWorld msg="You did it!" />

      <nav>
        <RouterLink to="/">Home</RouterLink>
        <RouterLink to="/about">About</RouterLink>
      </nav>
    </div> 
  </header> -->
<!-- <theHeader></theHeader> -->
  <RouterView />
</template>

<style>
@import url("https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap");

* {
  box-sizing: border-box;
}

html {
  font-family: "Roboto", sans-serif;
}

body {
  margin: 0;
}
</style>
