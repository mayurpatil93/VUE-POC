<template>
  <h1>Page not found</h1>
</template>

<script>
export default {
    name: "PageNotFound"
}
</script>

<style>

</style>