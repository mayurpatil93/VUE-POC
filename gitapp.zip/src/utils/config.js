const firebaseConfig = {
    apiKey: "AIzaSyAXiKJnQKNAyPaAzFdBezxYurSGjxucwJw",
    authDomain: "vue-poc-6cad0.firebaseapp.com",
    projectId: "vue-poc-6cad0",
    storageBucket: "vue-poc-6cad0.appspot.com",
    messagingSenderId: "100910957020",
    appId: "1:100910957020:web:e9a4351b2fc88443fb0f19"
  };

  export default firebaseConfig


